Hi!

Welcome to my site. On my site I share news that is of interest to me. On the right you can scroll 
through all the news and click on it. The button on the top left can be used to nagivate back home 
or go to any news page.

Github link: